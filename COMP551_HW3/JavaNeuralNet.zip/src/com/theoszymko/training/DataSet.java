package com.theoszymko.training;

public class DataSet {
	public double[][] inputs;
	public double[][] outputs;
	
	public DataSet(double[][] inputs, double[][] outputs) {
		this.inputs = inputs;
		this.outputs = outputs;
	}
}
