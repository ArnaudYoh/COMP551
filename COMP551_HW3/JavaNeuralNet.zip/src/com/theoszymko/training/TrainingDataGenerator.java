package com.theoszymko.training;

public abstract class TrainingDataGenerator {
	public abstract DataSet getDataSet();
}
