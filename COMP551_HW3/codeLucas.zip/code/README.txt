Run the methods file. 
One that is done, you can begin creating and training cnns. Note that the code will fail since the data will not be found. simply retoute loadData method to fetch your data. 